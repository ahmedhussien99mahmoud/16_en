# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_appointment
from . import test_appointment_invite
from . import test_appointment_ui
from . import test_event_notification
from . import test_onboarding
from . import test_performance
from . import test_res_partner
