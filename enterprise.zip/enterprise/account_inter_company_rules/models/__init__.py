# -*- coding: utf-8 -*-

from . import account_move
from . import res_config_settings
from . import res_company
