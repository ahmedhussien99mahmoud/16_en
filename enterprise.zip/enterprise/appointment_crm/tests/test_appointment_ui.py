# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import json

from datetime import datetime, timedelta

from odoo.addons.appointment.tests.common import AppointmentCommon
from odoo.tests import common, tagged, users


@tagged('appointment_ui', 'post_install', '-at_install')
class AppointmentCrmUITest(AppointmentCommon, common.HttpCase):

    @users('apt_manager')
    def test_route_create_custom_with_context(self):
        self.authenticate(self.env.user.login, self.env.user.login)
        now = datetime.now()
        unique_slots = [{
            'start': (now + timedelta(hours=1)).replace(microsecond=0).isoformat(' '),
            'end': (now + timedelta(hours=2)).replace(microsecond=0).isoformat(' '),
            'allday': False,
        }, {
            'start': (now + timedelta(days=2)).replace(microsecond=0).isoformat(' '),
            'end': (now + timedelta(days=3)).replace(microsecond=0).isoformat(' '),
            'allday': True,
        }]
        lead = self.env['crm.lead'].sudo().create({'name': 'Test Lead'})
        request = self.url_open(
            "/appointment/appointment_type/create_custom",
            data=json.dumps({
                'params': {
                    'slots': unique_slots,
                    'context': {
                        'default_assign_method': 'random',
                        'default_opportunity_id': lead.id,
                    },
                }
            }),
            headers={"Content-Type": "application/json"},
        ).json()
        result = request.get('result', dict())
        self.assertTrue(result.get('appointment_type_id'), 'The request returns the id of the custom appointment type')

        appointment_type = self.env['appointment.type'].browse(result['appointment_type_id'])
        # The default_assign_method should be ignored as the field is not whitelisted
        self.assertEqual(appointment_type.assign_method, 'chosen')
        # The default_opportunity_id should be propagated as the field is whitelisted
        self.assertEqual(appointment_type.opportunity_id, lead)
