# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import res_config_settings
from . import account_batch_payment
from . import account_journal
from . import account_journal_dashboard
from . import account_payment
from . import account_payment_method
from . import account_payment_register
from . import res_company
